<?php



if(isset($_GET['delete_list_payments'])){
	
	
	$invoice_number=$_GET['delete_list_payments'];
	echo $invoice_number;
	

		
		
	}
	





?>