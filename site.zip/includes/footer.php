

<!--last child-->

<div class="p-3 mt-5  text-center">
<p>ALL rights reserved - Designed by Shruti-2023</p>
 <p> <class="nav-item">
          <a class="nav-link " href="#">Contact</a>
        </p>

</div>
  </div>