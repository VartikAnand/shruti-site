<?php

$con=mysqli_connect('maxmovie.fun','wdgwlzeh_vartik','JcclHTZxY917','wdgwlzeh_shruti');
if(!$con){
	
	die(mysqli_error($con));
 
}

?>